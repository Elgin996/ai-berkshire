# Indicator contract

Use the TradingAgents-main public names and calculate all values from the same
frozen daily-bar sequence. Select at most eight unique baseline indicators.

## Baseline whitelist

| Family | Names | Use |
|---|---|---|
| Trend | `close_50_sma`, `close_200_sma`, `close_10_ema` | Medium/long trend and responsive price position |
| Momentum | `macd`, `macds`, `macdh`, `rsi` | Momentum, crossover state, and regime |
| Volatility | `boll`, `boll_ub`, `boll_lb`, `atr` | Band position and true-range volatility |
| Volume | `vwma` | Volume-weighted trend confirmation |

The portable runner uses the v1 parameters: SMA 20/50/200; EMA 10; MACD
12/26/9; RSI 14; Bollinger 20 with population standard deviation 2; ATR 14;
VWMA 20; volume/amount/turnover averages 5 and 20.

## Liquidity extension

These fields are execution context outside the eight-indicator limit:

| Field | Unit | Meaning | Missing-data rule |
|---|---|---|---|
| `volume` | shares | Daily traded volume | Sina and Eastmoney may provide it |
| `volume_5_sma`, `volume_20_sma` | shares | Average volume | Require non-null observations |
| `amount` | CNY | Daily traded value, Eastmoney `f57` | Never infer from price × volume |
| `amount_5_sma`, `amount_20_sma` | CNY | Average traded value | Null when amount is unavailable |
| `turnover_rate` | percent | Historical daily turnover, Eastmoney `f61` | Never replace with live quote |
| `turnover_rate_5_sma`, `turnover_rate_20_sma` | percent | Average historical turnover | Null when the source omits it |

`amount_percentile_60` is a 0–1 rolling percentile of the latest amount within
the available 60-observation window; it requires at least 20 observations.
Ratios are short-window average divided by long-window average and are null
when either denominator is unavailable or zero.

## Interpretation guardrails

- Cover trend, momentum, and volatility where data permits; avoid selecting
  every member of one family unless the complete state is needed.
- Treat MACD components as one family and Bollinger components as one family.
- Do not interpret ATR as directional by itself.
- Do not mechanically call RSI above 70 a reversal in a strong trend.
- Use liquidity facts only if their field availability and source are visible in
  the same snapshot.
- Keep raw, forward-adjusted, and backward-adjusted series separate.
