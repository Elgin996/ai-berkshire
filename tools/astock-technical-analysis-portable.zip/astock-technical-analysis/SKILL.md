---
name: astock-technical-analysis
description: Reproducible daily technical analysis for ordinary mainland China A-share stocks, using the TradingAgents-main eight-indicator selection discipline with portable Eastmoney/Sina historical bars, Tencent current turnover snapshots, point-in-time dates, liquidity fields, and explicit data-quality gates. Use when Codex needs to analyze an A-share code such as 600519, produce a Chinese technical report, or verify a report against a frozen snapshot.
---

# A-share technical analysis

Use this skill for ordinary mainland A-share stocks only. Keep the
TradingAgents-main baseline: select at most eight complementary indicators and
explain the evidence. Use the bundled runner for deterministic data and
calculations; it has no dependency on a TradingAgents repository or on a
project-specific absolute path.

Do not silently switch to Yahoo Finance, ETF/index semantics, a fixed signal
score, or a different vendor. Do not turn a technical state into Buy/Sell or
claim backtest performance without explicit trading rules and a fill model.

## Run the portable fact builder

Use Python 3.10+ and the standard library:

```bash
python3 /path/to/astock-technical-analysis/scripts/run_technical_snapshot.py \
  --symbol 600519 \
  --exchange SSE \
  --end-date YYYY-MM-DD \
  --as-of YYYY-MM-DD \
  --adjustment raw
```

The runner uses the source order `eastmoney -> sina`. Eastmoney's daily K-line
supplies historical amount (`f57`) and turnover rate (`f61`). Sina is an
OHLCV-only HTTP fallback, so a fallback report can have volume while amount and
historical turnover remain unavailable. Eastmoney retries transient edge
failures and tries HTTPS/HTTP; every attempt is exposed in the JSON payload.

The runner writes content-addressed snapshots to `.astock-technical-cache` in
the working directory. Use `--cache-dir` to choose another location,
`--mode prefer_cache` to reuse a request-matched snapshot, or
`--mode offline --snapshot-id sha256:...` to analyze a frozen snapshot without
network access. Keep the snapshot ID in the report.

For a current A-share date only, add `--include-live-quote`. This asks Tencent
for a current turnover percentage, price, and change percentage. It is a
separate real-time field, never part of the historical bars, and is omitted for
historical dates or offline mode.

## Workflow

1. Validate a six-digit mainland A-share code and resolve/verify SSE, SZSE, or
   BSE. Confirm that the instrument is an ordinary stock. Do not infer board,
   ST status, suspension, price-limit rule, or listing age from the code alone.
2. Freeze the requested date, adjustment basis, source attempts, quality
   report, and snapshot ID. Never use rows after `as_of`.
3. Apply the data gate: `A/B` allows a sourced analysis, `C` is observation-only,
   and `D/F` blocks a directional conclusion. Always disclose fallback status,
   stale data, warmup status, and missing liquidity fields.
4. Select no more than eight unique names from
   [references/indicator-contract.md](references/indicator-contract.md). Prefer
   trend, momentum, and volatility coverage; use VWMA only when volume is valid.
5. Read indicator values and liquidity facts from the runner JSON. Do not
   recalculate or invent values in prose. Amount and historical turnover are
   execution context outside the eight-indicator limit.
6. Write the Chinese report with: data scope; OHLCV overview; selected
   indicators and reasons; trend/momentum/volatility/volume interpretation;
   A-share execution constraints when verified; and risks/limitations.

## Required evidence rules

- Treat historical `turnover_rate` as percentage points. Treat Tencent's
  `turnover_pct` as current-only and never use it to fill a historical date.
- If amount or historical turnover is unavailable, write
  `[数据缺失: 成交额]` or `[数据缺失: 历史换手率]`; do not reconstruct either
  series from price, volume, or today's float shares.
- Report 5/20-day volume averages when available. Report 5/20-day amount and
  turnover averages only when those fields have sufficient observations in the
  same snapshot.
- Do not call a volume/amount ratio “放量确认” without showing its source,
  window, and calculation date.
- Do not mix raw and adjusted prices, current live data, different snapshots,
  or different vendors in one numerical claim.
- Distinguish facts, indicator meaning, and model inference. Technical
  indicators are lagging evidence, not investment advice.

## Output contract

The runner emits JSON with `request`, `quality`, `attempts`, `snapshot_id`,
`latest_bar`, `selected_indicators`, `indicators`, `liquidity`, and
`recent_closes`. The `liquidity` object contains latest volume/amount/turnover,
5/20-day averages, ratios, field availability, historical sources, and an
explicitly separated `live_turnover_rate` object.
