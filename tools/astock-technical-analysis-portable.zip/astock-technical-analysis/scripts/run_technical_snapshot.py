#!/usr/bin/env python3
"""Create a reproducible mainland A-share technical-analysis fact payload.

This portable runner deliberately has no dependency on TradingAgents-main or
TradingAgents-astock.  It uses the same public Eastmoney/Sina/Tencent data
endpoints, keeps the TradingAgents-main eight-indicator contract, and writes a
small content-addressed snapshot that Codex can cite in a report.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
import time
from dataclasses import asdict, dataclass
from datetime import date, datetime, time as dt_time, timedelta, timezone
from pathlib import Path
from typing import Any, Callable
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen


BASELINE_INDICATORS = (
    "close_50_sma",
    "close_200_sma",
    "close_10_ema",
    "macd",
    "macds",
    "macdh",
    "rsi",
    "boll",
    "boll_ub",
    "boll_lb",
    "atr",
    "vwma",
)

DEFAULT_INDICATORS = (
    "close_50_sma",
    "close_200_sma",
    "close_10_ema",
    "macd",
    "rsi",
    "boll",
    "atr",
    "vwma",
)

INDICATOR_COLUMNS = {
    "close_50_sma": "close_50_sma",
    "close_200_sma": "close_200_sma",
    "close_10_ema": "close_10_ema",
    "macd": "macd",
    "macds": "macds",
    "macdh": "macdh",
    "rsi": "rsi",
    "boll": "boll",
    "boll_ub": "boll_ub",
    "boll_lb": "boll_lb",
    "atr": "atr",
    "vwma": "vwma",
}

EM_RETRYABLE_STATUS = frozenset({408, 425, 429, 500, 502, 503, 504})
EM_URLS = (
    "https://push2his.eastmoney.com/api/qt/stock/kline/get",
    "http://push2his.eastmoney.com/api/qt/stock/kline/get",
)
SINA_URL = (
    "http://money.finance.sina.com.cn/quotes_service/api/json_v2.php/"
    "CN_MarketData.getKLineData"
)
TENCENT_URL = "https://qt.gtimg.cn/q="
MARKET_TZ = timezone(timedelta(hours=8))
INDICATOR_CONFIG_VERSION = "portable-indicators-v1"
REQUIRED_WARMUP = 220


class FetchError(RuntimeError):
    """A safe, short error from a public market-data endpoint."""

    def __init__(self, message: str, code: str = "network_error"):
        super().__init__(message)
        self.code = code


@dataclass
class Bar:
    trade_date: date
    open: float
    high: float
    low: float
    close: float
    volume: float | None
    amount: float | None
    turnover_rate: float | None
    source: str
    retrieved_at: str

    def as_json(self) -> dict[str, Any]:
        value = asdict(self)
        value["trade_date"] = self.trade_date.isoformat()
        return value


def _now_utc() -> datetime:
    return datetime.now(timezone.utc)


def _number(value: Any) -> float | None:
    if value is None or value == "" or value == "-":
        return None
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number if math.isfinite(number) else None


def _error_summary(exc: Exception) -> str:
    text = re.sub(r"https?://\S+", "<url>", str(exc))
    return text.replace("\n", " ")[:240]


def _json_default(value: Any) -> str:
    if isinstance(value, (date, datetime)):
        return value.isoformat()
    raise TypeError(f"unsupported JSON value: {type(value).__name__}")


def _canonical(value: Any) -> str:
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=_json_default,
    )


def _sha256(value: Any) -> str:
    return "sha256:" + hashlib.sha256(_canonical(value).encode("utf-8")).hexdigest()


def _exchange_prefix(exchange: str) -> str:
    return {"SSE": "sh", "SZSE": "sz", "BSE": "bj"}[exchange]


def _secid(symbol: str, exchange: str) -> str:
    market = {"SSE": 1, "SZSE": 0, "BSE": 0}[exchange]
    return f"{market}.{symbol}"


def _request_json(url: str, params: dict[str, Any], timeout: float) -> Any:
    query = urlencode(params)
    request = Request(
        f"{url}?{query}",
        headers={
            "User-Agent": (
                "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
                "Chrome/126.0 Safari/537.36"
            ),
            "Accept": "*/*",
            "Connection": "close",
        },
    )
    try:
        with urlopen(request, timeout=timeout) as response:
            status = int(response.getcode() or 200)
            body = response.read()
    except HTTPError as exc:
        if exc.code in EM_RETRYABLE_STATUS:
            raise FetchError(f"HTTP {exc.code}", "network_error") from exc
        raise FetchError(f"HTTP {exc.code}", "http_error") from exc
    except (URLError, TimeoutError, OSError) as exc:
        raise FetchError(_error_summary(exc), "network_error") from exc
    if status in EM_RETRYABLE_STATUS:
        raise FetchError(f"HTTP {status}", "network_error")
    if status >= 400:
        raise FetchError(f"HTTP {status}", "http_error")
    try:
        return json.loads(body.decode("utf-8-sig"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise FetchError("invalid JSON response", "schema_error") from exc


def _parse_em_kline(item: Any, retrieved_at: str) -> Bar | None:
    parts = str(item).split(",")
    if len(parts) < 7:
        return None
    try:
        trade_date = date.fromisoformat(parts[0][:10])
        open_price = float(parts[1])
        close = float(parts[2])
        high = float(parts[3])
        low = float(parts[4])
        volume = float(parts[5]) * 100.0
        amount = _number(parts[6])
        turnover = _number(parts[10]) if len(parts) > 10 else None
    except (TypeError, ValueError):
        return None
    return Bar(
        trade_date,
        open_price,
        high,
        low,
        close,
        volume,
        amount,
        turnover,
        "eastmoney",
        retrieved_at,
    )


def _fetch_eastmoney(
    symbol: str, exchange: str, start_date: date, end_date: date, adjustment: str
) -> list[Bar]:
    params = {
        "secid": _secid(symbol, exchange),
        "fields1": "f1,f2,f3,f4,f5,f6",
        "fields2": "f51,f52,f53,f54,f55,f56,f57,f58,f59,f60,f61",
        "klt": "101",
        "fqt": {"raw": "0", "forward": "1", "backward": "2"}[adjustment],
        "end": "20500101",
        "lmt": "800",
    }
    last_error: Exception | None = None
    for url in EM_URLS:
        for attempt in range(2):
            try:
                payload = _request_json(url, params, timeout=8)
                klines = ((payload.get("data") or {}).get("klines") or [])
                if not klines:
                    raise FetchError("empty K-line payload", "empty")
                retrieved_at = _now_utc().isoformat()
                rows = [
                    row
                    for item in klines
                    if (row := _parse_em_kline(item, retrieved_at)) is not None
                ]
                rows = [
                    row
                    for row in rows
                    if start_date <= row.trade_date <= end_date
                ]
                if not rows:
                    raise FetchError("no rows in requested date range", "empty")
                return sorted(rows, key=lambda row: row.trade_date)
            except FetchError as exc:
                last_error = exc
                if attempt == 0:
                    time.sleep(0.2)
    if last_error is None:
        raise FetchError("Eastmoney returned no response")
    raise last_error


def _fetch_sina(
    symbol: str, exchange: str, start_date: date, end_date: date, adjustment: str
) -> list[Bar]:
    if adjustment != "raw":
        raise FetchError("Sina fallback only supplies raw prices", "unsupported")
    params = {
        "symbol": f"{_exchange_prefix(exchange)}{symbol}",
        "scale": "240",
        "ma": "no",
        "datalen": "800",
    }
    payload = _request_json(SINA_URL, params, timeout=8)
    if not isinstance(payload, list) or not payload:
        raise FetchError("empty K-line payload", "empty")
    retrieved_at = _now_utc().isoformat()
    rows: list[Bar] = []
    for item in payload:
        try:
            trade_date = date.fromisoformat(str(item["day"])[:10])
            row = Bar(
                trade_date,
                float(item["open"]),
                float(item["high"]),
                float(item["low"]),
                float(item["close"]),
                _number(item.get("volume")),
                None,
                None,
                "sina",
                retrieved_at,
            )
        except (KeyError, TypeError, ValueError):
            continue
        if start_date <= row.trade_date <= end_date:
            rows.append(row)
    if not rows:
        raise FetchError("no rows in requested date range", "empty")
    return sorted(rows, key=lambda row: row.trade_date)


def _fetch_bars(
    symbol: str, exchange: str, start_date: date, end_date: date, adjustment: str
) -> tuple[list[Bar], list[dict[str, Any]]]:
    attempts: list[dict[str, Any]] = []
    sources: tuple[tuple[str, Callable[[], list[Bar]]], ...] = (
        (
            "eastmoney",
            lambda: _fetch_eastmoney(
                symbol, exchange, start_date, end_date, adjustment
            ),
        ),
        (
            "sina",
            lambda: _fetch_sina(symbol, exchange, start_date, end_date, adjustment),
        ),
    )
    for source, fetcher in sources:
        started = _now_utc()
        clock = time.monotonic()
        try:
            bars = fetcher()
            attempts.append(
                {
                    "source": source,
                    "started_at": started.isoformat(),
                    "elapsed_ms": int((time.monotonic() - clock) * 1000),
                    "status": "success",
                    "row_count": len(bars),
                    "first_date": bars[0].trade_date.isoformat(),
                    "last_date": bars[-1].trade_date.isoformat(),
                    "error_code": None,
                    "error_summary": None,
                }
            )
            return bars, attempts
        except Exception as exc:
            code = getattr(exc, "code", "network_error")
            attempts.append(
                {
                    "source": source,
                    "started_at": started.isoformat(),
                    "elapsed_ms": int((time.monotonic() - clock) * 1000),
                    "status": code,
                    "row_count": 0,
                    "first_date": None,
                    "last_date": None,
                    "error_code": code,
                    "error_summary": _error_summary(exc),
                }
            )
    return [], attempts


def _rolling_mean(values: list[float | None], period: int) -> list[float | None]:
    result: list[float | None] = [None] * len(values)
    for index in range(period - 1, len(values)):
        window = values[index - period + 1 : index + 1]
        if all(value is not None for value in window):
            result[index] = sum(value for value in window if value is not None) / period
    return result


def _rolling_std(values: list[float | None], period: int) -> list[float | None]:
    result: list[float | None] = [None] * len(values)
    for index in range(period - 1, len(values)):
        window = values[index - period + 1 : index + 1]
        if all(value is not None for value in window):
            numbers = [value for value in window if value is not None]
            mean = sum(numbers) / period
            result[index] = math.sqrt(sum((value - mean) ** 2 for value in numbers) / period)
    return result


def _ema(values: list[float | None], span: int, min_periods: int) -> list[float | None]:
    alpha = 2.0 / (span + 1.0)
    result: list[float | None] = []
    previous: float | None = None
    count = 0
    for value in values:
        if value is not None:
            previous = value if previous is None else alpha * value + (1 - alpha) * previous
            count += 1
        result.append(previous if previous is not None and count >= min_periods else None)
    return result


def _rsi(closes: list[float], period: int = 14) -> list[float | None]:
    gains: list[float | None] = [None]
    losses: list[float | None] = [None]
    for previous, current in zip(closes, closes[1:]):
        delta = current - previous
        gains.append(max(delta, 0.0))
        losses.append(max(-delta, 0.0))
    average_gain = _ema(gains, 2 * period - 1, period)
    average_loss = _ema(losses, 2 * period - 1, period)
    result: list[float | None] = []
    for gain, loss in zip(average_gain, average_loss):
        if gain is None or loss is None:
            result.append(None)
        elif loss == 0:
            result.append(100.0)
        else:
            result.append(100.0 - 100.0 / (1.0 + gain / loss))
    return result


def _atr(bars: list[Bar], period: int = 14) -> list[float | None]:
    true_ranges: list[float] = []
    previous_close: float | None = None
    for bar in bars:
        if previous_close is None:
            true_ranges.append(bar.high - bar.low)
        else:
            true_ranges.append(
                max(
                    bar.high - bar.low,
                    abs(bar.high - previous_close),
                    abs(bar.low - previous_close),
                )
            )
        previous_close = bar.close
    return _ema(true_ranges, 2 * period - 1, period)


def _vwma(closes: list[float], volumes: list[float | None], period: int = 20) -> list[float | None]:
    result: list[float | None] = [None] * len(closes)
    for index in range(period - 1, len(closes)):
        pairs = list(zip(closes[index - period + 1 : index + 1], volumes[index - period + 1 : index + 1]))
        if all(volume is not None for _, volume in pairs):
            denominator = sum(volume for _, volume in pairs if volume is not None)
            if denominator:
                result[index] = sum(close * volume for close, volume in pairs if volume is not None) / denominator
    return result


def _amount_percentile(values: list[float | None], period: int = 60) -> list[float | None]:
    result: list[float | None] = [None] * len(values)
    for index, current in enumerate(values):
        if current is None:
            continue
        window = [value for value in values[max(0, index - period + 1) : index + 1] if value is not None]
        if len(window) >= 20:
            result[index] = sum(value <= current for value in window) / len(window)
    return result


def _indicator_frame(bars: list[Bar]) -> dict[str, list[float | None]]:
    closes = [bar.close for bar in bars]
    highs = [bar.high for bar in bars]
    lows = [bar.low for bar in bars]
    volumes = [bar.volume for bar in bars]
    amounts = [bar.amount for bar in bars]
    turnovers = [bar.turnover_rate for bar in bars]

    ema_fast = _ema(closes, 12, 12)
    ema_slow = _ema(closes, 26, 26)
    macd = [
        fast - slow if fast is not None and slow is not None else None
        for fast, slow in zip(ema_fast, ema_slow)
    ]
    macds = _ema(macd, 9, 9)
    return {
        "close_50_sma": _rolling_mean(closes, 50),
        "close_200_sma": _rolling_mean(closes, 200),
        "close_10_ema": _ema(closes, 10, 10),
        "macd": macd,
        "macds": macds,
        "macdh": [
            value - signal if value is not None and signal is not None else None
            for value, signal in zip(macd, macds)
        ],
        "rsi": _rsi(closes),
        "boll": _rolling_mean(closes, 20),
        "boll_std": _rolling_std(closes, 20),
        "atr": _atr(bars),
        "vwma": _vwma(closes, volumes),
        "volume_5_sma": _rolling_mean(volumes, 5),
        "volume_20_sma": _rolling_mean(volumes, 20),
        "amount_5_sma": _rolling_mean(amounts, 5),
        "amount_20_sma": _rolling_mean(amounts, 20),
        "amount_percentile_60": _amount_percentile(amounts),
        "turnover_rate_5_sma": _rolling_mean(turnovers, 5),
        "turnover_rate_20_sma": _rolling_mean(turnovers, 20),
    }


def _latest(values: list[float | None]) -> float | None:
    return values[-1] if values else None


def _safe_ratio(numerator: float | None, denominator: float | None) -> float | None:
    if numerator is None or denominator in (None, 0):
        return None
    return numerator / denominator


def _empty_live_turnover(reason: str = "not_requested") -> dict[str, Any]:
    return {
        "value": None,
        "unit": "percent",
        "available": False,
        "source": None,
        "retrieved_at": None,
        "reason": reason,
        "semantics": "实时行情快照；不混入历史 as_of 序列",
    }


def _live_turnover(
    symbol: str,
    exchange: str,
    end_date: date,
    as_of: datetime,
    enabled: bool,
) -> dict[str, Any]:
    if not enabled:
        return _empty_live_turnover()
    market_today = datetime.now(MARKET_TZ).date()
    if end_date != market_today or as_of.date() != market_today:
        return _empty_live_turnover("historical_as_of")
    retrieved_at = _now_utc().isoformat()
    try:
        prefix = _exchange_prefix(exchange)
        request = Request(
            TENCENT_URL + prefix + symbol,
            headers={"User-Agent": "Mozilla/5.0"},
        )
        with urlopen(request, timeout=8) as response:
            raw = response.read().decode("gb18030", errors="replace")
        quote: dict[str, Any] | None = None
        for line in raw.split(";"):
            if "=" not in line or '"' not in line:
                continue
            key, quoted = line.split('"', 1)[0], line.split('"', 2)[1]
            code = key.split("=")[0].split("_")[-1]
            if code[2:] != symbol:
                continue
            values = quoted.split("~")
            if len(values) >= 40:
                quote = {
                    "price": _number(values[3]),
                    "change_pct": _number(values[32]),
                    "turnover_pct": _number(values[38]),
                }
                break
        if not quote:
            return {**_empty_live_turnover("quote_unavailable"), "retrieved_at": retrieved_at}
        value = quote["turnover_pct"]
        return {
            "value": value,
            "unit": "percent",
            "available": value is not None,
            "source": "tencent",
            "retrieved_at": retrieved_at,
            "reason": None if value is not None else "turnover_missing",
            "semantics": "腾讯当前实时换手率快照；不代表历史 as_of 日值",
            "price": quote["price"],
            "change_pct": quote["change_pct"],
        }
    except Exception as exc:
        return {
            **_empty_live_turnover(f"network_error: {type(exc).__name__}"),
            "retrieved_at": retrieved_at,
        }


def _quality(
    request: dict[str, Any], bars: list[Bar], attempts: list[dict[str, Any]]
) -> dict[str, Any]:
    last_date = bars[-1].trade_date if bars else None
    end_date = date.fromisoformat(request["end_date"])
    gap = max(0, (end_date - last_date).days) if last_date else None
    flags = ["calendar_ambiguous"] if bars else ["no_valid_bars"]
    if bars:
        flags.append("single_source_unverified")
    if len(bars) < REQUIRED_WARMUP and bars:
        flags.append("warmup_insufficient")
    if gap is not None and gap > 7:
        flags.append("stale")
    source = attempts[-1]["source"] if attempts and attempts[-1]["status"] == "success" else None
    if not bars:
        grade, decision, source_status = "F", "block", "UNAVAILABLE"
    elif "warmup_insufficient" in flags:
        grade, decision, source_status = "C", "observe_only", "FALLBACK_OK" if source != "eastmoney" else "PRIMARY_OK"
    else:
        grade = "B"
        decision = "allow"
        source_status = "PRIMARY_OK" if source == "eastmoney" else "FALLBACK_OK"
    freshness = 1.0 if gap is None or gap <= 3 else max(0.0, 1.0 - gap / 10.0)
    completeness = min(1.0, len(bars) / REQUIRED_WARMUP) if bars else 0.0
    lineage = ", ".join(
        f"{item['source']}:{item['status']}:{item['row_count']} rows" for item in attempts
    )
    return {
        "grade": grade,
        "decision": decision,
        "source_status": source_status,
        "completeness_score": completeness,
        "freshness_score": freshness,
        "consistency_score": 1.0 if bars else 0.0,
        "semantics_score": 1.0,
        "flags": flags,
        "missing_dates": [],
        "conflicts": [],
        "lineage_summary": lineage,
        "invalid_rows": 0,
        "total_rows": len(bars),
        "last_trade_date": last_date.isoformat() if last_date else None,
    }


def _snapshot_request(args: argparse.Namespace) -> dict[str, Any]:
    end_date = date.fromisoformat(args.end_date)
    start_date = date.fromisoformat(args.start_date) if args.start_date else end_date - timedelta(days=args.warmup_days)
    as_of = _as_of(args.as_of, end_date)
    return {
        "symbol": args.symbol,
        "exchange": args.exchange,
        "instrument_type": "stock",
        "start_date": start_date.isoformat(),
        "end_date": end_date.isoformat(),
        "frequency": "1d",
        "adjustment": args.adjustment,
        "as_of": as_of.isoformat(),
        "series_variant": "market_price",
        "currency": "CNY",
        "timezone": "Asia/Shanghai",
    }


def _as_of(value: str | None, end_date: date) -> datetime:
    if not value:
        return datetime.combine(end_date, dt_time.min, tzinfo=timezone.utc)
    parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    return parsed if parsed.tzinfo else parsed.replace(tzinfo=timezone.utc)


def _cache_paths(cache_dir: Path, request: dict[str, Any]) -> tuple[Path, Path]:
    key = hashlib.sha256(_canonical(request).encode("utf-8")).hexdigest()
    return cache_dir / f"request-{key}.json", cache_dir / "snapshots"


def _load_cached(cache_dir: Path, request: dict[str, Any], snapshot_id: str | None) -> dict[str, Any] | None:
    request_path, snapshot_dir = _cache_paths(cache_dir, request)
    path = snapshot_dir / f"{snapshot_id.removeprefix('sha256:')}.json" if snapshot_id else request_path
    if not path.is_file():
        return None
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    if snapshot_id and payload.get("snapshot_id") != snapshot_id:
        return None
    if not snapshot_id and payload.get("request") != request:
        return None
    return payload


def _save_cached(cache_dir: Path, payload: dict[str, Any]) -> None:
    request_path, snapshot_dir = _cache_paths(cache_dir, payload["request"])
    snapshot_dir.mkdir(parents=True, exist_ok=True)
    rendered = _canonical(payload) + "\n"
    (snapshot_dir / f"{payload['snapshot_id'].removeprefix('sha256:')}.json").write_text(rendered, encoding="utf-8")
    request_path.write_text(rendered, encoding="utf-8")


def _build_output(
    request: dict[str, Any],
    bars: list[Bar],
    attempts: list[dict[str, Any]],
    quality: dict[str, Any],
    snapshot_id: str | None,
    indicators: list[str],
    lookback_days: int,
    live_turnover: dict[str, Any],
) -> dict[str, Any]:
    frame = _indicator_frame(bars) if bars else {}
    latest = bars[-1] if bars else None
    boll = _latest(frame.get("boll", []))
    std = _latest(frame.get("boll_std", []))
    selected_values: dict[str, float | None] = {}
    for name in indicators:
        value = _latest(frame.get(INDICATOR_COLUMNS[name], []))
        if name == "boll_ub" and boll is not None and std is not None:
            value = boll + 2.0 * std
        elif name == "boll_lb" and boll is not None and std is not None:
            value = boll - 2.0 * std
        selected_values[name] = value

    def latest_frame(name: str) -> float | None:
        return _latest(frame.get(name, []))

    latest_amount = latest.amount if latest else None
    latest_turnover = latest.turnover_rate if latest else None
    amount_5 = latest_frame("amount_5_sma")
    amount_20 = latest_frame("amount_20_sma")
    turnover_5 = latest_frame("turnover_rate_5_sma")
    turnover_20 = latest_frame("turnover_rate_20_sma")
    liquidity = {
        "latest": {
            "volume": latest.volume if latest else None,
            "amount": latest_amount,
            "turnover_rate_pct": latest_turnover,
        },
        "moving_averages": {
            "volume_5_sma": latest_frame("volume_5_sma"),
            "volume_20_sma": latest_frame("volume_20_sma"),
            "amount_5_sma": amount_5,
            "amount_20_sma": amount_20,
            "amount_percentile_60": latest_frame("amount_percentile_60"),
            "turnover_rate_5_sma_pct": turnover_5,
            "turnover_rate_20_sma_pct": turnover_20,
        },
        "ratios": {
            "volume_5_to_20": _safe_ratio(latest_frame("volume_5_sma"), latest_frame("volume_20_sma")),
            "amount_5_to_20": _safe_ratio(amount_5, amount_20),
            "turnover_rate_5_to_20": _safe_ratio(turnover_5, turnover_20),
        },
        "availability": {
            "volume": {"available": any(bar.volume is not None for bar in bars), "unit": "shares"},
            "amount": {"available": any(bar.amount is not None for bar in bars), "unit": "CNY"},
            "turnover_rate": {"available": any(bar.turnover_rate is not None for bar in bars), "unit": "percent"},
        },
        "historical_sources": sorted({bar.source for bar in bars}),
        "live_turnover_rate": live_turnover,
    }
    return {
        "request": request,
        "snapshot_id": snapshot_id,
        "quality": quality,
        "attempts": attempts,
        "indicator_config_version": INDICATOR_CONFIG_VERSION,
        "selected_indicators": indicators,
        "latest_bar": latest.as_json() if latest else None,
        "indicators": selected_values,
        "liquidity": liquidity,
        "recent_closes": [
            {"trade_date": bar.trade_date.isoformat(), "close": bar.close}
            for bar in bars[-max(1, lookback_days) :]
        ],
    }


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--symbol", required=True, help="six-digit A-share code")
    parser.add_argument("--exchange", required=True, choices=("SSE", "SZSE", "BSE"))
    parser.add_argument("--end-date", required=True, help="analysis date, YYYY-MM-DD")
    parser.add_argument("--start-date", help="calculation start, YYYY-MM-DD")
    parser.add_argument("--as-of", help="point-in-time cutoff, ISO date or datetime")
    parser.add_argument("--adjustment", choices=("raw", "forward", "backward"), default="raw")
    parser.add_argument("--mode", choices=("online", "prefer_cache", "offline"), default="online")
    parser.add_argument("--snapshot-id", help="required for offline mode")
    parser.add_argument("--cache-dir", default=".astock-technical-cache")
    parser.add_argument("--warmup-days", type=int, default=400)
    parser.add_argument("--lookback-days", type=int, default=30)
    parser.add_argument("--indicator", action="append", help="baseline indicator; repeat or comma-separate")
    parser.add_argument("--include-live-quote", action="store_true", help="current-date Tencent turnover snapshot")
    parser.add_argument("--output", help="optional JSON output path")
    return parser


def _parse_indicators(values: list[str] | None) -> list[str]:
    selected: list[str] = []
    for raw in values or []:
        selected.extend(item.strip().lower() for item in raw.split(",") if item.strip())
    if not selected:
        return list(DEFAULT_INDICATORS)
    if len(selected) > 8:
        raise ValueError("at most eight indicators may be selected")
    if len(set(selected)) != len(selected):
        raise ValueError("indicator selection contains duplicates")
    unknown = sorted(set(selected) - set(BASELINE_INDICATORS))
    if unknown:
        raise ValueError(f"unsupported baseline indicator(s): {', '.join(unknown)}")
    return selected


def run(args: argparse.Namespace) -> tuple[dict[str, Any], int]:
    symbol = args.symbol.strip()
    if not re.fullmatch(r"\d{6}", symbol):
        raise ValueError("symbol must be a six-digit mainland A-share code")
    request = _snapshot_request(args)
    request["symbol"] = symbol
    indicators = _parse_indicators(args.indicator)
    cache_dir = Path(args.cache_dir).expanduser().resolve()
    cached: dict[str, Any] | None = None
    if args.mode == "offline":
        if not args.snapshot_id:
            raise ValueError("offline mode requires --snapshot-id")
        cached = _load_cached(cache_dir, request, args.snapshot_id)
        if cached is None:
            raise FileNotFoundError(f"snapshot not found: {args.snapshot_id}")
    elif args.mode == "prefer_cache":
        cached = _load_cached(cache_dir, request, None)

    if cached is not None:
        if cached.get("request") != request:
            raise ValueError("snapshot request does not match the requested symbol/date")
        bars = [
            Bar(
                date.fromisoformat(item["trade_date"]),
                float(item["open"]),
                float(item["high"]),
                float(item["low"]),
                float(item["close"]),
                _number(item.get("volume")),
                _number(item.get("amount")),
                _number(item.get("turnover_rate")),
                item["source"],
                item.get("retrieved_at", ""),
            )
            for item in cached.get("bars", [])
        ]
        attempts = cached.get("attempts", [])
        quality = cached.get("quality", {})
        snapshot_id = cached.get("snapshot_id")
    else:
        start_date = date.fromisoformat(request["start_date"])
        end_date = date.fromisoformat(request["end_date"])
        bars, attempts = _fetch_bars(symbol, args.exchange, start_date, end_date, args.adjustment)
        quality = _quality(request, bars, attempts)
        snapshot_body = {
            "request": request,
            "bars": [bar.as_json() for bar in bars],
            "attempts": attempts,
            "quality": quality,
        }
        snapshot_id = _sha256(snapshot_body)
        snapshot_body["snapshot_id"] = snapshot_id
        _save_cached(cache_dir, snapshot_body)

    as_of = _as_of(args.as_of, date.fromisoformat(args.end_date))
    live = _live_turnover(
        symbol,
        args.exchange,
        date.fromisoformat(args.end_date),
        as_of,
        args.include_live_quote and args.mode != "offline",
    )
    payload = _build_output(
        request,
        bars,
        attempts,
        quality,
        snapshot_id,
        indicators,
        args.lookback_days,
        live,
    )
    status = 0 if quality.get("decision") != "block" and bars else 2
    return payload, status


def main() -> int:
    args = _build_parser().parse_args()
    try:
        payload, status = run(args)
    except Exception as exc:
        payload, status = {"error": f"{type(exc).__name__}: {_error_summary(exc)}"}, 1
    rendered = json.dumps(payload, ensure_ascii=False, indent=2, allow_nan=False)
    if args.output:
        Path(args.output).expanduser().resolve().write_text(rendered + "\n", encoding="utf-8")
    print(rendered)
    return status


if __name__ == "__main__":
    raise SystemExit(main())
